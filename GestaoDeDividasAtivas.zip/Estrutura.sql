MulT1B#l0
		
Dívidas quitadas no período
Dívidas geradas no período
Dívidas acumuladas no período


-- public.tab_usuario definition

-- Drop table

-- DROP TABLE public.tab_usuario;

CREATE TABLE public.tab_usuario (
	id_usuario uuid NOT NULL,
	nome_usuario varchar(100) NOT NULL,
	login varchar(255) NOT NULL,
	senha varchar(255) NOT NULL,
	data_criacao timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	id_usuario_criacao uuid NOT NULL,
	data_edicao timestamp NULL,
	id_usuario_edicao uuid NULL,
	flg_ativo bool NOT NULL DEFAULT true,
	flg_removido bool NOT NULL DEFAULT false,
	CONSTRAINT tab_usuario_pk PRIMARY KEY (id_usuario),
	CONSTRAINT tab_usuario_un UNIQUE (login),
	CONSTRAINT tab_usuario_fk FOREIGN KEY (id_usuario_criacao) REFERENCES public.tab_usuario(id_usuario),
	CONSTRAINT tab_usuario_fk_1 FOREIGN KEY (id_usuario_edicao) REFERENCES public.tab_usuario(id_usuario)
);


-- public.tab_devedor definition

-- Drop table

-- DROP TABLE public.tab_devedor;

CREATE TABLE public.tab_devedor (
	id_devedor uuid NOT NULL,
	nome_devedor varchar(100) NOT NULL,
	caminho_foto_perfil varchar(255) NULL,
	flg_removido bool NOT NULL DEFAULT false,
	data_criacao timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	id_usuario_criacao uuid NOT NULL,
	data_edicao timestamp NULL,
	id_usuario_edicao uuid NULL,
	CONSTRAINT tab_devedor_pk PRIMARY KEY (id_devedor),
	CONSTRAINT tab_devedor_fk FOREIGN KEY (id_usuario_criacao) REFERENCES public.tab_usuario(id_usuario),
	CONSTRAINT tab_devedor_fk_1 FOREIGN KEY (id_usuario_edicao) REFERENCES public.tab_usuario(id_usuario)
);


-- public.tab_tipo_divida definition

-- Drop table

-- DROP TABLE public.tab_tipo_divida;

CREATE TABLE public.tab_tipo_divida (
	id_tipo_divida uuid NOT NULL,
	descricao varchar(100) NOT NULL,
	valor_unitario_aproximado numeric(10, 2) NOT NULL DEFAULT 0,
	data_criacao timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	id_usuario_criacao uuid NOT NULL,
	data_edicao timestamp NULL,
	id_usuario_edicao uuid NOT NULL,
	flg_removido bool NOT NULL DEFAULT false,
	CONSTRAINT tipo_divida_pk PRIMARY KEY (id_tipo_divida),
	CONSTRAINT tipo_divida_fk FOREIGN KEY (id_usuario_criacao) REFERENCES public.tab_usuario(id_usuario),
	CONSTRAINT tipo_divida_fk_1 FOREIGN KEY (id_usuario_edicao) REFERENCES public.tab_usuario(id_usuario)
);


-- public.tab_regra definition

-- Drop table

-- DROP TABLE public.tab_regra;

CREATE TABLE public.tab_regra (
	id_regra uuid NOT NULL,
	nome_regra varchar(100) NOT NULL,
	descricao varchar(1000) NULL,
	inicio_vigencia date NOT NULL,
	fim_vigencia date NOT NULL,
	flg_ativa bool NOT NULL DEFAULT true,
	data_criacao timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	id_usuario_criacao uuid NOT NULL,
	data_edicao timestamp NULL,
	id_usuario_edicao uuid NULL,
	id_tipo_divida uuid NOT NULL,
	CONSTRAINT tab_regra_pk PRIMARY KEY (id_regra),
	CONSTRAINT tab_regra_fk FOREIGN KEY (id_usuario_criacao) REFERENCES public.tab_usuario(id_usuario),
	CONSTRAINT tab_regra_fk_1 FOREIGN KEY (id_usuario_edicao) REFERENCES public.tab_usuario(id_usuario),
	CONSTRAINT tab_regra_fk_2 FOREIGN KEY (id_tipo_divida) REFERENCES public.tab_tipo_divida(id_tipo_divida)
);


-- public.tab_divida definition

-- Drop table

-- DROP TABLE public.tab_divida;

CREATE TABLE public.tab_divida (
	id_divida uuid NOT NULL,
	id_devedor uuid NOT NULL,
	id_regra uuid NOT NULL,
	id_tipo_divida uuid NOT NULL,
	motivo varchar(500) NOT NULL,
	data_divida date NOT NULL,
	data_quitacao date NULL,
	caminho_evidencia_quitacao varchar(255) NULL,
	data_criacao timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	id_usuario_criacao uuid NOT NULL,
	data_edicao timestamp NULL,
	id_usuario_edicao uuid NULL,
	quantidade_devida numeric(4, 2) NOT NULL DEFAULT 1,
	CONSTRAINT tab_divida_pk PRIMARY KEY (id_divida),
	CONSTRAINT tab_divida_fk FOREIGN KEY (id_regra) REFERENCES public.tab_regra(id_regra),
	CONSTRAINT tab_divida_fk_1 FOREIGN KEY (id_tipo_divida) REFERENCES public.tab_tipo_divida(id_tipo_divida),
	CONSTRAINT tab_divida_fk_2 FOREIGN KEY (id_devedor) REFERENCES public.tab_devedor(id_devedor),
	CONSTRAINT tab_divida_fk_3 FOREIGN KEY (id_usuario_criacao) REFERENCES public.tab_usuario(id_usuario),
	CONSTRAINT tab_divida_fk_4 FOREIGN KEY (id_usuario_edicao) REFERENCES public.tab_usuario(id_usuario)
);