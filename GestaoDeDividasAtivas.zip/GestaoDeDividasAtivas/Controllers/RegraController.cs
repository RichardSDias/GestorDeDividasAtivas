﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestaoDeDividasAtivas.Controllers
{
    //[Authorize]
    public class RegraController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Novo()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Novo([FromBody] object model)
        {
            return View();
        }

        [HttpGet]
        public IActionResult Editar(Guid id)
        {
            return View();
        }

        [HttpPost]
        public IActionResult Editar([FromBody] object model)
        {
            return View();
        }

        [HttpPost]
        public IActionResult Remover([FromBody] object model)
        {
            return View();
        }
    }
}
