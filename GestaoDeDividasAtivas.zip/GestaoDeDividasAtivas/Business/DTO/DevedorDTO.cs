﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GestaoDeDividasAtivas.Business.DTO
{
    public class DevedorDTO
    {
        public Guid IdDevedor { get; set; }
        [Required]
        [MaxLength(100, ErrorMessage = "O tamano máximo deverá ser de {0}")]
        [Display(Name = "Nome do usuário")]
        public string NomeDevedor { get; set; }
        [MaxLength(100, ErrorMessage = "O tamanho máximo deverá ser de {0}")]
        [Display(Name = "Foto de perfil")]
        public string CaminhoFotoPerfil { get; set; }
        public bool EstaRemovido { get; set; }
        [Display(Name = "Registrado em")]
        public DateTime DataCriacao { get; set; }
        [Display(Name = "Registrado por")]
        public Guid IdUsuarioCriacao { get; set; }
        [Display(Name = "Registrado por")]
        public string NomeUsuarioCriacao { get; set; }
        [Display(Name = "Editado em")]
        public DateTime DataEdicao { get; set; }
        [Display(Name = "Editado por")]
        public Guid IdUsuarioEdicao { get; set; }
        [Display(Name = "Editado por")]
        public string NomeUsuarioEdicao { get; set; }
    }
}