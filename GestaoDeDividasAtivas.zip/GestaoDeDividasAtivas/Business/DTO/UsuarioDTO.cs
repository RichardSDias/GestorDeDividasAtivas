﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GestaoDeDividasAtivas.Business.DTO
{
    public class UsuarioDTO
    {
        public Guid IdUsuario { get; set; }
        [Required]
        [MaxLength(100, ErrorMessage = "O tamanho máximo deverá ser de {0}")]
        [Display(Name = "Nome do usuário")] 
        public string NomeUsuario { get; set; }
        [Required]
        [MaxLength(255, ErrorMessage = "O tamanho máximo deverá ser de {0}")]
        public string Login { get; set; }
        [Required]
        [MaxLength(255, ErrorMessage = "O tamanho máximo deverá ser de {0}")]
        [MinLength(8, ErrorMessage = "O tamanho mínimo deverá ser de {0}")]
        public string Senha { get; set; }
        [Display(Name = "Está ativa?")]
        public bool EstaAtivo { get; set; }
        public bool EstaRemovido { get; set; }
        [Display(Name = "Registrado em")]
        public DateTime DataCriacao { get; set; }
        [Display(Name = "Registrado por")]
        public Guid IdUsuarioCriacao { get; set; }
        [Display(Name = "Registrado por")]
        public string NomeUsuarioCriacao { get; set; }
        [Display(Name = "Editado em")]
        public DateTime DataEdicao { get; set; }
        [Display(Name = "Editado por")]
        public Guid IdUsuarioEdicao { get; set; }
        [Display(Name = "Editado por")]
        public string NomeUsuarioEdicao { get; set; }
    }
}
