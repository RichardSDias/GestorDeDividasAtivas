﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GestaoDeDividasAtivas.Business.DTO
{
    public class TipoDividaDTO
    {
        public Guid IdTipoDivida { get; set; }
        [Required]
        [Display(Name = "Descrição")]
        [MaxLength(100, ErrorMessage = "O tamanho máximo deve ser {0}")]
        public string Descricao { get; set; }
        [Display(Name = "Valor unitário aproximado")]
        [Range(minimum: 0, maximum: Int32.MaxValue, ErrorMessage = "O valor deve ser maior que 0")]
        public decimal ValorUnitarioAproximado { get; set; }
        public bool EstaRemovido { get; set; }
        [Display(Name = "Registrada em")]
        public DateTime DataCriacao { get; set; }
        [Display(Name = "Registrada por")]
        public Guid IdUsuarioCriacao { get; set; }
        [Display(Name = "Registrada por")]
        public string NomeUsuarioCriacao { get; set; }
        [Display(Name = "Editada em")]
        public DateTime DataEdicao { get; set; }
        [Display(Name = "Editada por")]
        public Guid IdUsuarioEdicao { get; set; }
        [Display(Name = "Editada por")]
        public string NomeUsuarioEdicao { get; set; }
    }
}
