﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GestaoDeDividasAtivas.Business.DTO
{
    public class RegraDTO
    {
        public Guid IdRegra { get; set; }
        [Required]
        [Display(Name = "Nome da regra")]
        [MinLength(100, ErrorMessage = "O tamanho máximo dever ser menor que {0}")]
        public string NomeRegra { get; set; }
        [Required]
        [Display(Name = "Descrição")]
        [MinLength(1000, ErrorMessage = "O tamanho máximo dever ser menor que {0}")]
        public string Descriao { get; set; }
        [Required]
        [Display(Name = "Data início vigência")]
        public DateTime DataInicioVigencia { get; set; }
        [Display(Name = "Data término vigência")]
        public DateTime DataFimVigencia { get; set; }

        [Display(Name = "Tipo de dívida")]
        public Guid IdTipoDivida { get; set; }
        [Display(Name = "Tipo de dívida")]
        public string DescricaoTipoDivida { get; set; }
        public decimal ValorUnitarioAproximado { get; set; }
        [Display(Name = "Está ativa?")]
        public bool EstaAtiva { get; set; }
        [Display(Name = "Registrada em")]
        public DateTime DataCriacao { get; set; }
        [Display(Name = "Registrada por")]
        public Guid IdUsuarioCriacao { get; set; }
        [Display(Name = "Registrada por")]
        public string NomeUsuarioCriacao { get; set; }
        [Display(Name = "Editada em")]
        public DateTime DataEdicao { get; set; }
        [Display(Name = "Editada por")]
        public Guid IdUsuarioEdicao { get; set; }
        [Display(Name = "Editada por")]
        public string NomeUsuarioEdicao { get; set; }
    }
}