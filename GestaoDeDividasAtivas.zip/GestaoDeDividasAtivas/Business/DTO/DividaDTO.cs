﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GestaoDeDividasAtivas.Business.DTO
{
    public class DividaDTO
    {
        public Guid IdDivida { get; set; }
        [Display(Name = "Devedor")]
        public Guid IdDevedor { get; set; }
        [Display(Name = "Devedor")]
        public string NomeDevedor { get; set; }
        [Display(Name = "Regra")]
        public Guid IdRegra { get; set; }

        [Display(Name = "Regra")]
        public string NomeRegra { get; set; }
        [Display(Name = "Tipo de dívida")]
        public Guid IdTipoDivida { get; set; }
        [Display(Name = "Tipo de dívida")]
        public string DescricaoTipoDivida { get; set; }
        [Display(Name = "Valor unitário aproximado")]
        public decimal ValorUnitarioAproximado { get; set; }
        [Display(Name = "Quantidade devida")]
        public decimal QuantidadeDevida { get; set; }
        public string Motivo { get; set; }
        [Display(Name = "Data da dívida")]
        public DateTime DataDivida { get; set; }
        [Display(Name = "Data de quitação")]
        public DateTime DataQuitacao { get; set; }
        [Display(Name = "Evidência de quitação")]
        public string CaminhoEvidenciaQuitacao { get; set; }
        [Display(Name = "Registrada em")]
        public DateTime DataCriacao { get; set; }
        [Display(Name = "Registrada por")]
        public Guid IdUsuarioCriacao { get; set; }
        [Display(Name = "Registrada por")]
        public string NomeUsuarioCriacao { get; set; }
        [Display(Name = "Editada em")]
        public DateTime DataEdicao { get; set; }
        [Display(Name = "Editada por")]
        public Guid IdUsuarioEdicao { get; set; }
        [Display(Name = "Editada por")]
        public string NomeUsuarioEdicao { get; set; }
    }
}