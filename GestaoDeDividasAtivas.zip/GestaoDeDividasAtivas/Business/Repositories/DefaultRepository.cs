﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;
using System.Data.Common;

namespace GestaoDeDividasAtivas.Business.Repositories
{
    public class DefaultRepository
    {
        private IConfiguration _Configuration;

        private readonly string _connectionString;
        public DefaultRepository(string stringConnection)
        {
            this._connectionString = stringConnection;
        }
        public DefaultRepository(IConfiguration configuration)
        {
            this._connectionString = _Configuration.GetConnectionString("DefaultConnection");
        }

        public  DbConnection GetConnection()
        {
            return new NpgsqlConnection(_connectionString);
        }
    }
}